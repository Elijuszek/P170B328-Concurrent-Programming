package main

import "sync"

// TODO: all lock unlock cond funbctionality must be implemented here:
type DataMonitor struct {
	Cities []City
	mutex  sync.Mutex
	maxLen int
	count  int
	cond   *sync.Cond
}

func (dm *DataMonitor) AllocateDataMonitor(setMaxLen int) {
	dm.Cities = make([]City, 0, setMaxLen)
	dm.maxLen = setMaxLen
	dm.count = 0
	dm.cond = sync.NewCond(&dm.mutex)
}

func (dm *DataMonitor) addItem(city City) {
	dm.mutex.Lock()
	for dm.count == dm.maxLen {
		// Array is full wait for an item to be removed
		dm.cond.Wait()
	}

	defer dm.mutex.Unlock()
	dm.Cities = append(dm.Cities, city)
	dm.count++
}

func (dm *DataMonitor) removeItem() City {
	dm.mutex.Lock()
	defer dm.mutex.Unlock()
	if dm.count == 0 {
		return City{Name: "", Population: 0, Area: 0}
	}
	city := dm.Cities[dm.count-1]
	dm.Cities = dm.Cities[:dm.count-1]
	dm.count--
	dm.cond.Signal()
	return city
}

type ResultMonitor struct {
	computedCities []ComputedCity
	mutex          sync.Mutex
}

func (rm *ResultMonitor) addItem(compCity ComputedCity) {
	if compCity.City.Area < 20000 {
		return
	}
	rm.mutex.Lock()
	defer rm.mutex.Unlock()
	for i := 0; i < len(rm.computedCities); i++ {
		if compCity.City.Population >= rm.computedCities[i].City.Population {
			var allocateCity = new(ComputedCity)
			rm.computedCities = append(rm.computedCities, *allocateCity)
			copy(rm.computedCities[i+1:], rm.computedCities[i:])
			rm.computedCities[i] = compCity
			return
		}
	}
	rm.computedCities = append(rm.computedCities, compCity)
}

func (rm *ResultMonitor) getItems() []ComputedCity {
	return rm.computedCities
}
